# TaskFlow — Código-fonte (esqueleto Android)

Este código implementa, na prática, as decisões documentadas na **Wiki Técnica de UI** e, a partir desta entrega, também os conceitos de persistência de dados do **Módulo 5** do projeto TaskFlow. Ele foi organizado para servir como base de estudo e desenvolvimento ao longo da disciplina — não é um app 100% funcional/publicável (por exemplo, a integração real com Firebase precisa ser configurada com seu próprio `google-services.json`), mas toda a estrutura de telas, layouts, fragmentos e persistência local está implementada e comentada.

## Como abrir
1. Abra a pasta `TaskFlow/` no Android Studio (File > Open).
2. Deixe o Gradle sincronizar (vai baixar as dependências listadas em `app/build.gradle`).
3. Para rodar de verdade com Firebase, você precisará criar um projeto no [Firebase Console](https://console.firebase.google.com), baixar o `google-services.json` e colocá-lo em `app/`, além de aplicar o plugin `com.google.gms.google-services` no `app/build.gradle`. Sem isso, o app compila normalmente e as tarefas já são salvas de verdade no banco SQLite local — só a sincronização remota via Firebase é que não vai funcionar.

## Onde encontrar cada item da wiki no código

| Seção da wiki | Onde está no código |
|---|---|
| **1. Layouts** | `res/layout/activity_login.xml` (LinearLayout), `res/layout/activity_main.xml` (ConstraintLayout + FrameLayout), `res/layout/fragment_task_detail.xml` (ScrollView) |
| **2. Views e componentes** | `item_task.xml` (CheckBox, RecyclerView), `fragment_task_detail.xml` (EditText, Spinner, Button), `TaskDetailFragment.kt` (DatePickerDialog programático via `showDatePicker()`) |
| **3. XML x código** | Todas as telas estáticas em `res/layout/*.xml`; conteúdo dinâmico (itens da lista, spinner) montado em `TaskAdapter.kt` e `TaskDetailFragment.kt` |
| **4. Orientação de tela** | `TaskViewModel.kt` (sobrevive à rotação) + `onSaveInstanceState` em `TaskDetailFragment.kt` |
| **5. Fragmentos especializados** | `TaskListFragment.kt` (papel do ListFragment), `ConfirmDeleteDialogFragment.kt` (DialogFragment), `SettingsFragment.kt` (PreferenceFragmentCompat) |

## Onde encontrar cada item do Módulo 5 no código

| Conceito do módulo | Onde está no código |
|---|---|
| **SharedPreferences (salvar/ler)** | `LoginActivity.kt` grava usuário lembrado e último login em `getSharedPreferences("TaskFlowPrefs", ...)` |
| **Compartilhamento entre Activities via getSharedPreferences()** | `MainActivity.kt` lê o mesmo arquivo `TaskFlowPrefs` gravado pela `LoginActivity.kt` |
| **Armazenamento interno — FileOutputStream** | `SettingsFragment.kt`, método `exportTasksToInternalStorage()`, via `openFileOutput()` |
| **Leitura de arquivo interno — FileInputStream + InputStreamReader** | `SettingsFragment.kt`, método `importTasksFromInternalStorage()`, via `openFileInput()` |
| **Armazenamento externo — getExternalStorageDirectory()** | `SettingsFragment.kt`, método `exportTasksToExternalStorage()` |
| **Leitura de res/raw — openRawResource()** | `SettingsFragment.kt`, método `showAboutDialog()`, lendo `res/raw/sobre_taskflow.txt` |
| **Database Helper — SQLiteOpenHelper** | `data/TaskDbHelper.kt`, tabela `tasks`, usada por `TaskViewModel.kt` no lugar da antiga lista mock |

## Estrutura de pastas

```
TaskFlow/
├── build.gradle
├── settings.gradle
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/taskflow/
        │   ├── data/            → Task.kt, TaskDbHelper.kt, TaskViewModel.kt
        │   ├── adapter/         → TaskAdapter.kt
        │   └── ui/
        │       ├── login/       → LoginActivity.kt
        │       ├── main/        → MainActivity.kt
        │       ├── task/        → TaskListFragment.kt, TaskDetailFragment.kt,
        │       │                  ConfirmDeleteDialogFragment.kt
        │       └── settings/    → SettingsFragment.kt, SettingsActivity.kt
        └── res/
            ├── layout/          → todos os .xml de tela
            ├── values/          → strings.xml, colors.xml, themes.xml, arrays.xml
            ├── xml/             → preferences.xml
            └── raw/             → sobre_taskflow.txt
```

## Observação sobre ListFragment
A atividade pede o uso de `ListFragment`. Essa classe está **depreciada** no Android atual, substituída por `Fragment` + `RecyclerView`. O `TaskListFragment.kt` cumpre o mesmo papel pedido (lista reutilizável, independente da Activity), usando a abordagem atualmente recomendada pela documentação oficial — isso está comentado no próprio arquivo, caso você queira citar essa decisão na wiki ou no fórum.

## Observação sobre getExternalStorageDirectory()
De forma parecida com o `ListFragment`, o método `getExternalStorageDirectory()` pedido pela atividade do Módulo 5 também está **depreciado** desde o Android 10 (API 29), em favor do Scoped Storage. Como a atividade pede explicitamente esse método, ele foi implementado em `SettingsFragment.kt`, com `android:requestLegacyExternalStorage="true"` no Manifest e permissões com `maxSdkVersion` para manter a compatibilidade — tudo comentado no código, para você poder citar essa decisão na wiki caso precise.
